
# создайте таблицу 
# cursor.execute("""
# CREATE TABLE IF NOT EXISTS students (
#     id INTEGER PRIMARY KEY AUTOINCREMENT,
#     first_name TEXT NOT NULL,
#     last_name TEXT NOT NULL,
#     city TEXT,
#     age INTEGER,
#     course INTEGER,
#     faculty TEXT,
#     email TEXT UNIQUE,
#     phone TEXT,
#     gpa REAL DEFAULT 0.0
# )
# """)

# connection.commit()
# print("Таблица students создана")

# добавьте свои данные
# cursor.execute("DELETE FROM students")
# connection.commit()


# students_data = [
#     ("Анна", "Иванова", "Москва", 19, 2, "Информатика", "anna@student.com", "+79111111111", 4.8),
#     ("Максим", "Петров", "СПб", 20, 3, "Математика", "maxim@student.com", "+79222222222", 4.5),
#     ("Дарья", "Сидорова", "Киев", 18, 1, "Физика", "darya@student.com", "+79333333333", 4.9),
#     ("Артем", "Козлов", "Минск", 21, 4, "Информатика", "artem@student.com", "+79444444444", 4.2),
#     ("Екатерина", "Морозова", "Москва", 19, 2, "Экономика", "ekaterina@student.com", "+79555555555", 4.7)
# ]

# cursor.executemany("""
# INSERT INTO students (first_name, last_name, city, age, course, faculty, email, phone, gpa)
# VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
# """, students_data)


# print(f"Добавлено {len(students_data)} студентов")

# # сохраните изменения
# connection.commit()
# print("Изменения сохранены")



# cursor.execute("SELECT * FROM students")

# students = cursor.fetchall()

# print("\n".join(map(str, students)))

# assert len(students) >= 3

# for student in students:
#     print("ID:", student[0], "| Имя:", student[1], "| Город:", student[2], "| Возраст:", student[3])


# cursor.execute(
#     "SELECT * FROM students WHERE city = ?",
#     ("Москва",)
# )

# moskva_students = cursor.fetchall()

# print("\n".join(map(str, moskva_students)))
# print(moskva_students)

# assert len(moskva_students) >= 1

# cursor.execute("""
# CREATE TABLE IF NOT EXISTS revenues (
#     id INTEGER PRIMARY KEY AUTOINCREMENT,
#     company_name TEXT,
#     revenue_amount REAL,
#     revenue_date TEXT,
#     category TEXT,
#     region TEXT
# )
# """)

# connection.commit()

# print("Таблица revenues создана")


def create_main_table(connection):
    cursor = connection.cursor()
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS revenues (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        company_name TEXT,
        revenue_amount REAL,
        revenue_date TEXT,
        category TEXT,
        region TEXT
    )
    """)
    connection.commit()


